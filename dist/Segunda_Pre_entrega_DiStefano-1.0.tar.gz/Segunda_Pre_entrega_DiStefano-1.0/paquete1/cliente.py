from modulo1 import baseDeDatos, usuarios

class Cliente1():
  def __init__(self,nombre,email,edad):
    self.nombre=nombre
    self.email=email
    self.edad=edad

def comprar(self):
  print("La compra se ha realizado con exito!")

  usuario1 = Cliente1(baseDeDatos[1], "dep@hotmail.com", "22")

  print(usuario1)