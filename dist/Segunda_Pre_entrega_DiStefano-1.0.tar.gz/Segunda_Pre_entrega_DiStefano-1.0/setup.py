from setuptools import setup

setup(
    name = "Segunda_Pre_entrega_DiStefano",
    version = "1.0",
    description = "Paquete",
    author = "DiStefano",
    author_email = "maximiliano.distefano@hotmail.com",
    packages = ["paquete1"]
)